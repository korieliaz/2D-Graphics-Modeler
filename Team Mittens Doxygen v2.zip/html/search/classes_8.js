var searchData=
[
  ['text',['Text',['../class_text.html',1,'']]]
];
