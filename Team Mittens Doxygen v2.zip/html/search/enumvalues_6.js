var searchData=
[
  ['polygon',['POLYGON',['../namespace_shape_labels.html#a766c29253a4e09254c9cd0ef34ea405eac064d775cfe3f3e961d4ad57c04b4b54',1,'ShapeLabels']]],
  ['polyline',['POLYLINE',['../namespace_shape_labels.html#a766c29253a4e09254c9cd0ef34ea405ea6143eb8d556313ad887377872e1f8d1f',1,'ShapeLabels']]]
];
