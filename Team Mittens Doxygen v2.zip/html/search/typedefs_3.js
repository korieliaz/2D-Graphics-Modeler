var searchData=
[
  ['perimeter',['perimeter',['../namespacedim.html#a3a978faea5c6bf9b464ed7f01bab88b7',1,'dim']]]
];
