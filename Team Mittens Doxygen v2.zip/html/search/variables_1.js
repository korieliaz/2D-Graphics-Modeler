var searchData=
[
  ['brush',['brush',['../class_shape.html#aa67647c3a5d39d1e3f63a241208e59f2',1,'Shape']]],
  ['brush_5fstyles',['BRUSH_STYLES',['../qtconversions_8h.html#a95c7a8c9c3514814163a4197d7c72a71',1,'qtconversions.h']]],
  ['brushstylesar',['brushStylesAr',['../qtconversions_8h.html#afc807e8a815265eddfc8ae4e680f1825',1,'qtconversions.h']]],
  ['brushstylestring',['brushStyleString',['../qtconversions_8h.html#a3f52eb0a784bdd9fe007e2b43ee61cb5',1,'qtconversions.h']]]
];
