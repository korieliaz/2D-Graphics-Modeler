var searchData=
[
  ['shapedimensions',['shapeDimensions',['../class_shape.html#aec18b6b06a8b68389ab675b3f278f542',1,'Shape']]],
  ['shapeid',['shapeId',['../class_shape.html#a1578a3f17dd6b921083413c0b53c3b96',1,'Shape']]],
  ['shapes_5flist',['SHAPES_LIST',['../namespace_shape_labels.html#afc1d337f9ba5a35992a43ff46e47224f',1,'ShapeLabels']]],
  ['shapetype',['shapeType',['../class_shape.html#a1f91f9bf27f61ee5396cb5a0b53daf49',1,'Shape']]]
];
