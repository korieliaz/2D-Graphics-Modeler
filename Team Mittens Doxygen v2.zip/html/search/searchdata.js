var indexSectionsWithContent =
{
  0: "abcdefghijlmnopqrstuvwxy~",
  1: "acelmprstv",
  2: "dmsu",
  3: "acelmpqrstv",
  4: "abcdefgilmnoprstuvw~",
  5: "abcfgjmnpst",
  6: "aciprs",
  7: "des",
  8: "abcehlprstwxy"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "enumvalues"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Enumerations",
  8: "Enumerator"
};

