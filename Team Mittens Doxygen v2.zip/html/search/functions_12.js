var searchData=
[
  ['what',['what',['../classshape_exception.html#af473a7ffe91f1d6a3398864663654f19',1,'shapeException']]]
];
