var searchData=
[
  ['rectangle',['Rectangle',['../class_rectangle.html#a8a933e0ebd9e80ce91e61ffe87fd577e',1,'Rectangle::Rectangle()'],['../class_rectangle.html#a52b85aabb852711c04b715bd6ef4e90a',1,'Rectangle::Rectangle(int shapeId, std::string shapeType, int numDimensions, dim::specs *shapeDimensions)']]],
  ['reserve',['reserve',['../classmy_vector_1_1vector.html#a4479588783be3c2bc9840a5663145671',1,'myVector::vector']]],
  ['resize',['resize',['../classmy_vector_1_1vector.html#a910085289786d722cf4d871fd4e88219',1,'myVector::vector']]]
];
