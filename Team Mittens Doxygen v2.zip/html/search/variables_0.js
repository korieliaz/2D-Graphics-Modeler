var searchData=
[
  ['alignflag',['alignFlag',['../class_shape.html#a7ab13f8750711670dc3ab6b5c39afeb9',1,'Shape']]]
];
