var searchData=
[
  ['side',['side',['../namespacedim.html#a6d872abb4a2861287e9d2e7f40d6e52b',1,'dim']]],
  ['specs',['specs',['../namespacedim.html#a037077d8adcac68de2b8fd6a60ae24e2',1,'dim']]]
];
