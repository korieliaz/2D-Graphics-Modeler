var searchData=
[
  ['b',['B',['../class_ellipse.html#a461724419116d554de3156261865fb6ca9d5ed678fe57bcca610140957afab571',1,'Ellipse']]],
  ['begin',['begin',['../classmy_vector_1_1vector.html#a139b7c473c2283dbc9f5c9d8b6206209',1,'myVector::vector::begin()'],['../classmy_vector_1_1vector.html#a282480d074e98b0567bca9111c016b5f',1,'myVector::vector::begin() const']]],
  ['brush',['brush',['../class_shape.html#aa67647c3a5d39d1e3f63a241208e59f2',1,'Shape']]],
  ['brush_5fstyles',['BRUSH_STYLES',['../qtconversions_8h.html#a95c7a8c9c3514814163a4197d7c72a71',1,'qtconversions.h']]],
  ['brushstylesar',['brushStylesAr',['../qtconversions_8h.html#afc807e8a815265eddfc8ae4e680f1825',1,'qtconversions.h']]],
  ['brushstylestring',['brushStyleString',['../qtconversions_8h.html#a3f52eb0a784bdd9fe007e2b43ee61cb5',1,'qtconversions.h']]]
];
