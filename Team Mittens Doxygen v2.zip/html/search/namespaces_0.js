var searchData=
[
  ['dim',['dim',['../namespacedim.html',1,'']]]
];
