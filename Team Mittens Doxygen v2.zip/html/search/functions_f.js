var searchData=
[
  ['text',['Text',['../class_text.html#ab3e26143fccc52699bcc5149cae852bc',1,'Text::Text()'],['../class_text.html#aaf1ea175d900f3489cdb5f7d502fe97c',1,'Text::Text(int shapeId, std::string shapeType, int numDimensions, dim::specs *shapeDimensions, QFont newFont, std::string newText, Qt::AlignmentFlag newFlag)']]]
];
