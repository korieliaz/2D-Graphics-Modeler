var searchData=
[
  ['globalcolorstring',['globalColorString',['../qtconversions_8h.html#ad4bb164dfcaf7cd6ed076a26cb6dca0c',1,'qtconversions.h']]]
];
