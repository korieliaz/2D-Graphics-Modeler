var searchData=
[
  ['editshape',['editShape',['../class_all_shapes.html#a6d8da2a37265790068b67e65a8feb91d',1,'AllShapes::editShape(int id, const int NUM_SPECS, dim::specs *dims, const QPen &amp;pen)'],['../class_all_shapes.html#aa91b46c64fc18b90d9b69e4b59b91815',1,'AllShapes::editShape(int id, const int NUM_SPECS, dim::specs *dims, const QPen &amp;pen, const QBrush &amp;brush)'],['../class_all_shapes.html#a206b69c49a7dd79bdb4e8697327389ff',1,'AllShapes::editShape(int id, const int NUM_SPECS, dim::specs *dims, const QPen &amp;pen, const QFont &amp;font, Qt::AlignmentFlag flag, string text)']]],
  ['ellipse',['Ellipse',['../class_ellipse.html',1,'Ellipse'],['../class_ellipse.html#aaff4917eddd8882616fe2f956151ba9b',1,'Ellipse::Ellipse()'],['../class_ellipse.html#a6a886ccb82aadabee87ab8d41c76dfbe',1,'Ellipse::Ellipse(int shapeId, std::string shapeType, int numDimensions, dim::specs *shapeDimensions)'],['../namespace_shape_labels.html#a766c29253a4e09254c9cd0ef34ea405ea8b972e0f222b2bdd896e4a501e4e79be',1,'ShapeLabels::ELLIPSE()']]],
  ['ellipse_2ecpp',['ellipse.cpp',['../ellipse_8cpp.html',1,'']]],
  ['ellipse_2eh',['ellipse.h',['../ellipse_8h.html',1,'']]],
  ['end',['end',['../classmy_vector_1_1vector.html#a6cea15b6b5316590d740f47aa5b07687',1,'myVector::vector::end()'],['../classmy_vector_1_1vector.html#ab599997f36d99d5e2d395be90f0ea315',1,'myVector::vector::end() const']]],
  ['erase',['erase',['../classmy_vector_1_1vector.html#ab37eac3fa34a42e037fd704ff9398c93',1,'myVector::vector']]],
  ['eshapes',['eShapes',['../namespace_shape_labels.html#a766c29253a4e09254c9cd0ef34ea405e',1,'ShapeLabels']]]
];
