var searchData=
[
  ['ellipse',['ELLIPSE',['../namespace_shape_labels.html#a766c29253a4e09254c9cd0ef34ea405ea8b972e0f222b2bdd896e4a501e4e79be',1,'ShapeLabels']]]
];
