var searchData=
[
  ['max_5ftext_5fpoint',['MAX_TEXT_POINT',['../shape_8h.html#aeedc312999f2d97abc72b0547b2c452a',1,'shape.h']]],
  ['min_5ftext_5fpoint',['MIN_TEXT_POINT',['../shape_8h.html#ab40b58c78508fa73f1bc940fef1fab1d',1,'shape.h']]]
];
