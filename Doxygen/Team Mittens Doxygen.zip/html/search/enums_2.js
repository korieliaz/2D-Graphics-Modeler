var searchData=
[
  ['specifications',['Specifications',['../class_circle.html#aded9a0cd1ac3a8a28e16a69785914bc2',1,'Circle::Specifications()'],['../class_ellipse.html#a461724419116d554de3156261865fb6c',1,'Ellipse::Specifications()'],['../class_line.html#ad76023d3ce4f9c478d181ce73c9058a9',1,'Line::Specifications()'],['../class_rectangle.html#a2dfeebea96acc8abb71585dba8f3bf9d',1,'Rectangle::Specifications()'],['../class_square.html#ad906c5ea7bf71816bd45daf1a0cba837',1,'Square::Specifications()'],['../class_text.html#aae659c9396b17cfdaf0d144bf0722d71',1,'Text::Specifications()']]]
];
