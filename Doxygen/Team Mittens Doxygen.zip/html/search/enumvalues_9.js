var searchData=
[
  ['text',['TEXT',['../namespace_shape_labels.html#a766c29253a4e09254c9cd0ef34ea405ead1ce6f10001cbdedef7062276999f9b2',1,'ShapeLabels']]]
];
