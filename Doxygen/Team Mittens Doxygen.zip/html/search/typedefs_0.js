var searchData=
[
  ['area',['area',['../namespacedim.html#af33c68e944e78389e73debe68528a218',1,'dim']]],
  ['axis',['axis',['../namespacedim.html#af7c0ddd573a03479836291f558717d8a',1,'dim']]]
];
