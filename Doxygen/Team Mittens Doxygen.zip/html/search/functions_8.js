var searchData=
[
  ['line',['Line',['../class_line.html#acc11b8a429d8cdd63ba6803dff5602b3',1,'Line::Line()'],['../class_line.html#ada8d650cd3503a64b099533a15849523',1,'Line::Line(int shapeId, std::string shapeType, int numDimensions, dim::specs *shapeDimensions)']]]
];
