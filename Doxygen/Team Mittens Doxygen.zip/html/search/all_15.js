var searchData=
[
  ['w',['W',['../class_rectangle.html#a2dfeebea96acc8abb71585dba8f3bf9da61e9c06ea9a85a5088a499df6458d276',1,'Rectangle::W()'],['../class_text.html#aae659c9396b17cfdaf0d144bf0722d71a61e9c06ea9a85a5088a499df6458d276',1,'Text::W()']]],
  ['what',['what',['../classshape_exception.html#af473a7ffe91f1d6a3398864663654f19',1,'shapeException']]]
];
