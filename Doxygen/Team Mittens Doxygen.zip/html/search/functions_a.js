var searchData=
[
  ['newshape',['newShape',['../class_all_shapes.html#ad6811291344337c4d42e48fa128162c8',1,'AllShapes']]]
];
