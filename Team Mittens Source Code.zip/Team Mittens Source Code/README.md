**Programmers:**  
Kori Eliaz          <korieliaz@outlook.com>  
Trevor Dunham       <trevor_d@outlook.com>  
Michael Sinclair    <masinclair2@gmail.com>  
Brian Ferguson      <bferguson@gmail.com>  
Mariah Harris       <mariahh2017@gmail.com>  
Ali Bingol          <mythologyali@gmail.com>  
Peter Win           <peterzin@gmail.com>  
Braden Wurlitzer    <wurlitzerb@gmail.com>  
<br />
**Date:**  
Fall 2018  
<br />
**Copyright:**  
Team Mittens USA  
CS1C w/ Professor John Kath  
Saddleback College  